create procedure hg_create_table_like(table_name text, query_sql text)
    security definer
    language plpgsql
as
$$
begin
  EXECUTE 'CALL hg_create_table_like (' || quote_literal(table_name) || ',' || quote_literal(query_sql) || ','''')';
end;
$$;

alter procedure hg_create_table_like(text, text) owner to holo_admin;

