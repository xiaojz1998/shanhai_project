create view vi_app_log_test(dt, vid, eid, country_code, uid) as
SELECT to_timestamp(app_user_track_log_bak20250120.created_at::double precision)::date AS dt,
       app_user_track_log_bak20250120.vid,
       app_user_track_log_bak20250120.eid,
       app_user_track_log_bak20250120.country_code,
       app_user_track_log_bak20250120.uid
FROM app_user_track_log_bak20250120
WHERE 1 = 1
  AND app_user_track_log_bak20250120.event_name::text = 'drama_watch_time'::text
  AND app_user_track_log_bak20250120.watch_time > 3
  AND to_timestamp(app_user_track_log_bak20250120.created_at::double precision)::date >= '2024-09-10'::date
GROUP BY (to_timestamp(app_user_track_log_bak20250120.created_at::double precision)::date),
         app_user_track_log_bak20250120.vid, app_user_track_log_bak20250120.eid,
         app_user_track_log_bak20250120.country_code, app_user_track_log_bak20250120.uid;

comment on view vi_app_log_test is '用户行为数据视图';

alter table vi_app_log_test
    owner to "cs_data_log.public.developer";

grant select on vi_app_log_test to "cs_data_log.public.viewer";

grant delete, insert, references, select, trigger, truncate, update on vi_app_log_test to "cs_data_log.public.writer";

