create view v_dim_country_area_bak20250121(id, country_name, country_code, sort, dcomment, area, area2, 国家分类) as
SELECT COALESCE(c.id, a.id::bigint)     AS id,
       COALESCE(c.name, a.country_name) AS country_name,
       COALESCE(c.code, a.country_code) AS country_code,
       COALESCE(c.sort, a.sort::bigint) AS sort,
       CASE
           WHEN c.code IS NULL THEN '补充'::text
           ELSE '正常'::text
           END                          AS dcomment,
       a.area,
       a.area2,
       a.country_grade                  AS "国家分类"
FROM middle_country c
         FULL JOIN tmp_country_input a ON c.code = a.country_code;

alter table v_dim_country_area_bak20250121
    owner to "cs_data_log.public.developer";

grant select on v_dim_country_area_bak20250121 to "cs_data_log.public.viewer";

grant delete, insert, references, select, trigger, truncate, update on v_dim_country_area_bak20250121 to "cs_data_log.public.writer";

