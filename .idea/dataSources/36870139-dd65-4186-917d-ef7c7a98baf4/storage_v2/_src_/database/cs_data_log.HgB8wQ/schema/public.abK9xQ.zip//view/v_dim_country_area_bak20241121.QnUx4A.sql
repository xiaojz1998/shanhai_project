create view v_dim_country_area_bak20241121(id, country_name, country_code, sort, area) as
SELECT DISTINCT t1.id,
                t1.country_name,
                t1.country_code,
                t1.sort,
                t1.area
FROM (SELECT c.id,
             c.name  AS country_name,
             c.code  AS country_code,
             c.sort,
             CASE
                 WHEN c.code = ANY (ARRAY ['AU'::text, 'NZ'::text]) THEN '澳新'::text
                 WHEN c.code = ANY (ARRAY ['US'::text, 'CA'::text, 'MX'::text, 'GL'::text]) THEN '北美'::text
                 WHEN c.code = ANY
                      (ARRAY ['BN'::text, 'KH'::text, 'ID'::text, 'LA'::text, 'MY'::text, 'MM'::text, 'PH'::text, 'SG'::text, 'TH'::text, 'VN'::text])
                     THEN '东南亚'::text
                 WHEN c.code = ANY
                      (ARRAY ['AO'::text, 'BJ'::text, 'BW'::text, 'BF'::text, 'BI'::text, 'CV'::text, 'CM'::text, 'CF'::text, 'TD'::text, 'KM'::text, 'CG'::text, 'CD'::text, 'CI'::text, 'DJ'::text, 'GQ'::text, 'ER'::text, 'ET'::text, 'GA'::text, 'GM'::text, 'GH'::text, 'GN'::text, 'GW'::text, 'KE'::text, 'LS'::text, 'LR'::text, 'MG'::text, 'MW'::text, 'ML'::text, 'MR'::text, 'MU'::text, 'MZ'::text, 'NA'::text, 'NE'::text, 'NG'::text, 'RW'::text, 'ST'::text, 'SN'::text, 'SC'::text, 'SL'::text, 'SO'::text, 'ZA'::text, 'SS'::text, 'SZ'::text, 'TZ'::text, 'TG'::text, 'UG'::text, 'ZM'::text, 'ZW'::text])
                     THEN '非洲'::text
                 WHEN c.code = ANY
                      (ARRAY ['AT'::text, 'BE'::text, 'BG'::text, 'HR'::text, 'CY'::text, 'CZ'::text, 'DK'::text, 'EE'::text, 'FI'::text, 'FR'::text, 'DE'::text, 'GR'::text, 'HU'::text, 'IE'::text, 'IT'::text, 'LV'::text, 'LT'::text, 'LU'::text, 'MT'::text, 'NL'::text, 'PL'::text, 'PT'::text, 'RO'::text, 'SK'::text, 'SI'::text, 'ES'::text, 'SE'::text, 'IS'::text, 'LI'::text, 'NO'::text, 'RU'::text, 'UA'::text, 'CH'::text, 'GI'::text, 'BA'::text, 'BY'::text, 'MK'::text, 'VA'::text, 'GB'::text])
                     THEN '欧洲'::text
                 WHEN c.code = ANY (ARRAY ['JP'::text, 'KR'::text]) THEN '日韩'::text
                 WHEN c.code = ANY
                      (ARRAY ['DZ'::text, 'BH'::text, 'JO'::text, 'IQ'::text, 'IR'::text, 'IL'::text, 'SA'::text, 'KW'::text, 'LB'::text, 'OM'::text, 'QA'::text, 'GE'::text, 'AE'::text, 'PS'::text, 'EG'::text, 'LY'::text, 'MA'::text, 'SD'::text, 'SY'::text, 'TN'::text])
                     THEN '中东'::text
                 WHEN c.code = ANY
                      (ARRAY ['BR'::text, 'AR'::text, 'BO'::text, 'EC'::text, 'FK'::text, 'CO'::text, 'CL'::text, 'PE'::text, 'PY'::text, 'GY'::text, 'GF'::text, 'VE'::text, 'UY'::text, 'SR'::text])
                     THEN '南美洲'::text
                 WHEN c.code = ANY (ARRAY ['TW'::text, 'MO'::text, 'HK'::text]) THEN '中国(繁体)'::text
                 WHEN c.code = 'CN'::text THEN '中国(简体)'::text
                 ELSE '其他'::text
                 END AS area
      FROM middle_country c
      UNION ALL
      SELECT '1239'::bigint AS id,
             '英国'::text   AS country_name,
             'UK'::text     AS country_code,
             '1239'::bigint AS sort,
             '欧洲'::text   AS area
      UNION ALL
      SELECT '1240'::bigint  AS id,
             '未知'::text    AS country_name,
             'UNKNOWN'::text AS country_code,
             '1240'::bigint  AS sort,
             '未知'::text    AS area) t1;

comment on view v_dim_country_area_bak20241121 is '国家区域维度表';

alter table v_dim_country_area_bak20241121
    owner to "cs_data_log.public.developer";

grant select on v_dim_country_area_bak20241121 to "cs_data_log.public.viewer";

grant delete, insert, references, select, trigger, truncate, update on v_dim_country_area_bak20241121 to "cs_data_log.public.writer";

