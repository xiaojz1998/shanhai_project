create procedure hg_create_table_like(table_name text, query_sql text, partition_clause text)
    security definer
    language plpgsql
as
$$
declare
  table_def text;
  table_exist bool;
begin

  IF (table_name is NULL OR length(table_name) < 1) THEN
    raise exception 'table name cannot be null';
  END IF;

  IF (query_sql is NULL OR length(query_sql) < 1) THEN
    raise exception 'query cannot be null';
  END IF;

  EXECUTE 'SELECT count(*) > 0 FROM pg_class WHERE relname = ' || quote_literal(table_name) INTO table_exist;

  IF (table_exist = true) THEN
    raise exception 'table % already exists', table_name;
  END IF;

  select hg_get_query_schema(table_name, query_sql, partition_clause) into table_def;
  execute table_def;
end;
$$;

alter procedure hg_create_table_like(text, text, text) owner to holo_admin;

